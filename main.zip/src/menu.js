export class Menu{
    constructor(){
        this.list=['치킨','피자','한식','양식','일식','패스트푸드','분식'];
    }
}
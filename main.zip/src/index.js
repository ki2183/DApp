import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import Serchbar from './Serchbar';
import Nav from './Nav';
import Mainbanner from './Mainbanner';
import Login from './Login';
import reportWebVitals from './reportWebVitals';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <Nav/>
    {/* <Serchbar></Serchbar>
    <Mainbanner></Mainbanner> */}
    <Login></Login>
  </React.StrictMode>
);
reportWebVitals();

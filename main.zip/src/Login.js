import './Login.css';
function LoginWindow(){
    
}
function Login(){
    const contain = document.querySelector(".container-login");
    console.log(contain)
  return (
    <div className="container-login">
        
    </div>
  );
}

export default Login;
